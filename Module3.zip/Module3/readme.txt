All of the output will be in the output.txt file.

Compile with the command below
###########################################
gcc -std=c99 -o compile module3.c ArrayList.c module3.h ArrayList.h
./compile
###########################################

1.Eric Howard
2.Bruno Franco
